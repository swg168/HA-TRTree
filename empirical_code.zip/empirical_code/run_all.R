source("R/00_prepare_data.R")
source("R/01_fit.R")
source("R/02_ppp.R")
writeLines(format(Sys.time()),"output/FULL_RUN_COMPLETE.txt")
