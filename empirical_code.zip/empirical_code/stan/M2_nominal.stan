// Original nominal model extended to six cells. C_Human reference (original HS).
// One person trait; NC_Miss slope=-1; five team-by-cell effects; no value effects.
data {
  int<lower=1> R;
  int<lower=1> H;
  int<lower=1> A;
  int<lower=1> C;
  int<lower=1> T;
  array[R] int<lower=1, upper=H> hh;
  array[R] int<lower=1, upper=A> aa;
  array[R] int<lower=1, upper=C> cc;
  array[R] int<lower=1, upper=T> tt;
  array[R, 6] int<lower=0> n;
}
parameters {
  vector[H] z_theta;
  real<lower=0> sigma_theta;
  array[A, C] vector[5] icpt;
  vector[4] slope_free;
  array[T] vector[5] z_eps;
  real<lower=0> sigma_eps;
}
transformed parameters {
  vector[H] theta = sigma_theta * z_theta;
  vector[5] slope = append_row(-1, slope_free);
  matrix[R, 5] base;
  for (r in 1 : R) 
    base[r] = (icpt[aa[r], cc[r]] + slope * theta[hh[r]]
               + sigma_eps * z_eps[tt[r]])';
}
model {
  z_theta ~ std_normal();
  sigma_theta ~ normal(0, 1);
  slope_free ~ normal(0, 2);
  for (a in 1 : A) 
    for (c in 1 : C) 
      icpt[a, c] ~ normal(0, 2);
  for (t in 1 : T) 
    z_eps[t] ~ std_normal();
  sigma_eps ~ normal(0, 1);
  for (r in 1 : R) {
    vector[5] x = base[r]';
    vector[6] logits = [x[1], x[2], x[3], x[4], 0, x[5]]';
    target += multinomial_logit_lupmf(n[r] | logits);
  }
}
generated quantities {
  vector[R] log_lik_round;
  array[A, C, 6] int n_rep_ac = rep_array(0, A, C, 6);
  for (r in 1 : R) {
    vector[5] x = base[r]';
    vector[6] logits = [x[1], x[2], x[3], x[4], 0, x[5]]';
    array[6] int repn = multinomial_rng(softmax(logits), sum(n[r]));
    log_lik_round[r] = multinomial_lpmf(n[r] | softmax(logits));
    for (m in 1 : 6) 
      n_rep_ac[aa[r], cc[r], m] += repn[m];
  }
}

