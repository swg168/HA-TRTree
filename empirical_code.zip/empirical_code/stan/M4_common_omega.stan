// Five-node six-leaf tree; shared round v across NC/conflict; beta ~ normal(0,1).
functions {
  vector tree_log_probs(real xp, real xq, real xs0, real xrho, real xs1) {
    vector[6] lp;
    lp[1] = log_inv_logit(xp) + log1m_inv_logit(xs0);
    lp[2] = log_inv_logit(xp) + log_inv_logit(xs0) + log_inv_logit(xrho);
    lp[3] = log_inv_logit(xp) + log_inv_logit(xs0) + log1m_inv_logit(xrho);
    lp[4] = log1m_inv_logit(xp) + log1m_inv_logit(xs1);
    lp[5] = log1m_inv_logit(xp) + log_inv_logit(xs1) + log_inv_logit(xq);
    lp[6] = log1m_inv_logit(xp) + log_inv_logit(xs1) + log1m_inv_logit(xq);
    return lp;
  }
}
data {
  int<lower=1> R;
  int<lower=1> H;
  int<lower=1> A;
  int<lower=1> C;
  matrix[A*C, A*C-1] alpha_basis; // orthonormal zero-sum contrasts
  int<lower=1> T;
  array[R] int<lower=1, upper=H> hh;
  array[R] int<lower=1, upper=A> aa;
  array[R] int<lower=1, upper=C> cc;
  array[R] int<lower=1, upper=T> tt;
  array[R, 6] int<lower=0> n;
}
transformed data {
  array[R] int nc;
  array[R] int total;
  array[R] int nc_caught;
  array[R] int nh;
  array[R] int ch;
  array[R] int ca;
  array[R] int c_caught;
  array[R] int conflict_total;
  for (r in 1 : R) {
    nc[r] = n[r, 1] + n[r, 2] + n[r, 3];
    total[r] = sum(n[r]);
    nc_caught[r] = n[r, 2] + n[r, 3];
    nh[r] = n[r, 2];
    ch[r] = n[r, 5];
    ca[r] = n[r, 6];
    c_caught[r] = ch[r] + ca[r];
    conflict_total[r] = total[r] - nc[r];
  }
}
parameters {
  matrix[2, H] z_person; // standardized (theta, kappa)
  cholesky_factor_corr[2] L_person;
  real<lower=0> sigma_theta;
  real<lower=0> sigma_kappa;
  matrix[A, C] gamma; // coordination: AI x density
  matrix[A, C] eta; // AI resistance in contests
  vector[A*C-1] alpha_z;
  matrix[A, C] beta; // conflict minus no-conflict interception log-odds
  matrix[A, C] zeta; // contribution-share intercept
  real<lower=0, upper=1> omega; // ONE human weight in team ability
  real<lower=0> lambda;
  vector[R] z_u;
  vector[R] z_v;
  vector<lower=0>[A] sigma_u;
  vector<lower=0>[A] sigma_v;
  
  real b0; // ONE common difficulty, no value-specific parameters
}
transformed parameters {
  matrix[A, C] alpha = to_matrix(alpha_basis * alpha_z, A, C);
  vector[H] theta;
  vector[H] kappa;
  {
    matrix[2, H] p = L_person * z_person;
    theta = sigma_theta * p[1]';
    kappa = sigma_kappa * p[2]';
  }
  
  vector[R] xpi;
  vector[R] xq;
  vector[R] xs;
  vector[R] xrho;
  vector[R] xs1;
  for (r in 1 : R) {
    xpi[r] = kappa[hh[r]] + gamma[aa[r], cc[r]] + sigma_u[aa[r]] * z_u[r];
    xq[r] = theta[hh[r]] - eta[aa[r], cc[r]];
    xs[r] = omega * theta[hh[r]] + (1 - omega) * alpha[aa[r], cc[r]] - b0
            + sigma_v[aa[r]] * z_v[r];
    xrho[r] = lambda * theta[hh[r]] - zeta[aa[r], cc[r]];
    xs1[r] = xs[r] + beta[aa[r], cc[r]];
  }
}
model {
  to_vector(z_person) ~ std_normal();
  L_person ~ lkj_corr_cholesky(2);
  sigma_theta ~ normal(0, 1);
  sigma_kappa ~ normal(0, 1);
  to_vector(gamma) ~ normal(0, 2);
  to_vector(eta) ~ normal(0, 2);
  alpha_z ~ normal(0, 2 * sqrt((A*C) / (1.0 * (A*C-1))));
  to_vector(beta) ~ normal(0, 1);
  to_vector(zeta) ~ normal(0, 2);
  omega ~ beta(2, 2);
  lambda ~ normal(0, 1);
  z_u ~ std_normal();
  z_v ~ std_normal();
  sigma_u ~ normal(0, 1);
  sigma_v ~ normal(0, 1);
  
  b0 ~ normal(0, 2);
  target += binomial_logit_lupmf(nc | total, xpi);
  target += binomial_logit_lupmf(nc_caught | nc, xs);
  target += binomial_logit_lupmf(nh | nc_caught, xrho);
  target += binomial_logit_lupmf(ch | c_caught, xq);
  target += binomial_logit_lupmf(c_caught | conflict_total, xs1);
}
generated quantities {
  real r_theta_kappa = multiply_lower_tri_self_transpose(L_person)[1, 2];
  matrix[A, C] ai_contrib;
  vector[R] log_lik_round;
  array[A, C, 6] int n_rep_ac = rep_array(0, A, C, 6);
  for (a in 1 : A) 
    for (c in 1 : C) 
      ai_contrib[a, c] = (1 - omega) * alpha[a, c];
  for (r in 1 : R) {
    vector[6] lp = tree_log_probs(xpi[r], xq[r], xs[r], xrho[r], xs1[r]);
    array[6] int repn = multinomial_rng(softmax(lp), sum(n[r]));
    log_lik_round[r] = multinomial_lpmf(n[r] | softmax(lp));
    for (m in 1 : 6) 
      n_rep_ac[aa[r], cc[r], m] += repn[m];
  }
}

