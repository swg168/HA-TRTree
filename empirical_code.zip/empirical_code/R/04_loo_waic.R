# Direct use of the stored Stan log_lik_round; no marginalization or refitting.
source("R/00_config.R")
suppressPackageStartupMessages(library(loo))
dest<-"output/conditional_round_criteria"
dir.create(dest,recursive=TRUE,showWarnings=FALSE)
R<-readRDS("output/prepared_data.rds")$stan$R
loos<-waics<-list()
for(key in names(MODELS)){
 cat(format(Sys.time()),"Extract",key,"log_lik_round\n");flush.console()
 fit<-readRDS(file.path("output",key,"fit.rds"))
 draws<-as.data.frame(fit$draws("log_lik_round",format="draws_df"))
 ll<-as.matrix(draws[,sprintf("log_lik_round[%d]",seq_len(R)),drop=FALSE])
 chain_id<-draws$.chain
 stopifnot(identical(dim(ll),c(4000L,R)),all(is.finite(ll)),length(unique(chain_id))==4L)
 reff<-loo::relative_eff(exp(sweep(ll,2,apply(ll,2,max),"-")),chain_id=chain_id)
 waics[[key]]<-loo::waic(ll)
 loos[[key]]<-loo::loo(ll,r_eff=reff,cores=4)
 print(waics[[key]]);print(loos[[key]]);flush.console()
 saveRDS(list(loo=loos[[key]],waic=waics[[key]],variable="log_lik_round",unit="round",
  random_effects="conditioned on; not integrated",draws=4000L,chains=4L),file.path(dest,paste0(key,"_criteria.rds")))
 write.csv(data.frame(round=seq_len(R),pareto_k=loo::pareto_k_values(loos[[key]]),
  elpd_loo=loos[[key]]$pointwise[,"elpd_loo"],p_waic=waics[[key]]$pointwise[,"p_waic"]),
  file.path(dest,paste0(key,"_pointwise_diagnostics.csv")),row.names=FALSE)
 rm(fit,draws,ll);gc()
}
cl<-as.data.frame(loo::loo_compare(loos));cw<-as.data.frame(loo::loo_compare(waics))
if(!"model" %in% names(cl))cl$model<-rownames(cl)
if(!"model" %in% names(cw))cw$model<-rownames(cw)
tab<-do.call(rbind,lapply(names(MODELS),function(key){
 l<-loos[[key]]$estimates;w<-waics[[key]]$estimates;k<-loo::pareto_k_values(loos[[key]])
 data.frame(model=key,WAIC=w["waic",1],se_WAIC=w["waic",2],p_waic=w["p_waic",1],
 LOOIC=l["looic",1],se_LOOIC=l["looic",2],elpd_loo=l["elpd_loo",1],p_loo=l["p_loo",1],
 elpd_diff=cl$elpd_diff[match(key,cl$model)],se_diff=cl$se_diff[match(key,cl$model)],
 n_rounds=R,k_gt_07=sum(k>.7),k_gt_07_percent=100*mean(k>.7),k_gt_1=sum(k>1),max_k=max(k),
 waic_variance_gt_04=sum(waics[[key]]$pointwise[,"p_waic"]>.4))
}))
tab$delta_WAIC<-tab$WAIC-min(tab$WAIC);tab$delta_LOOIC<-tab$LOOIC-min(tab$LOOIC)
stopifnot(!anyNA(tab),max(abs(tab$delta_LOOIC+2*tab$elpd_diff))<1e-7)
tab<-tab[order(tab$LOOIC),]
write.csv(tab,file.path(dest,"comparison.csv"),row.names=FALSE)
write.csv(cl,file.path(dest,"loo_compare.csv"),row.names=FALSE)
write.csv(cw,file.path(dest,"waic_compare.csv"),row.names=FALSE)
saveRDS(list(loo=loos,waic=waics,loo_compare=cl,waic_compare=cw),file.path(dest,"objects.rds"))
lines<-c("# 直接使用Stan log_lik_round的WAIC与PSIS-LOO","",
 sprintf("使用全部4链4000次后验抽样，直接从fit提取log_lik_round；逐点单位为%d个轮次，保留已拟合随机效应，不积分、不重新拟合。",R),"",
 "| 模型 | WAIC | ΔWAIC | LOOIC | ΔLOOIC | Δelpd (SE) | k>0.7 | k>1 |",
 "|---|---:|---:|---:|---:|---:|---:|---:|")
for(i in seq_len(nrow(tab))){v<-tab[i,];lines<-c(lines,sprintf("| %s | %.2f | %.2f | %.2f | %.2f | %.2f (%.2f) | %d | %d |",v$model,v$WAIC,v$delta_WAIC,v$LOOIC,v$delta_LOOIC,v$elpd_diff,v$se_diff,v$k_gt_07,v$k_gt_1))}
lines<-c(lines,"","WAIC、LOOIC越小越好。若Pareto k>0.7较多，则PSIS近似不稳定，不能忽略诊断解释排名。WAIC也应同时查看逐点方差超过0.4的数量，见comparison.csv。各模型收敛诊断另见output/fit_diagnostics.csv。",
 "","本分析使用五节点六分类全数据fit，不使用分值标签。loo_compare的SE按轮次计算，没有按人聚类；这些结果不等同于新参与者K-fold预测得分。",
 "",paste("loo version:",packageVersion("loo")))
writeLines(lines,file.path(dest,"结果说明.md"),useBytes=TRUE)
print(tab,digits=9,row.names=FALSE)
cat("DONE: direct conditional-round WAIC and PSIS-LOO\n")
