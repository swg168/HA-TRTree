# Same mean-count statistic and mixed predictive replication as code/R/04_ppc.R.
# Six categories, no target value effects. Uses full-data fits; never refits.
source("R/00_config.R")
dest <- file.path(OUT_DIR,"ppp_manuscript_method")
dir.create(dest,recursive=TRUE,showWarnings=FALSE)
s <- readRDS(file.path(OUT_DIR,"prepared_data.rds"))$stan
N <- as.matrix(s$n); nr <- nrow(N); totals <- rowSums(N)
ac <- s$aa+s$A*(s$cc-1L); groups <- s$A*s$C
ng <- tabulate(ac,nbins=groups)
observed <- rowsum(N,ac,reorder=TRUE)
stopifnot(ncol(N)==6L,all(ng>0),nr==1108L,sum(N)==180668L)
alltab <- list(); summaries <- list()
for(key in names(MODELS)) {
  fit <- readRDS(file.path(OUT_DIR,key,"fit.rds"))
  lp <- apply(fit$draws("lp__",format="draws_array"),2,mean)
  keep <- seq_along(lp) # Preserve all four chains; diagnose mixing separately.
  vars <- if(key=="M2") c("theta","sigma_eps","icpt","slope") else
    c("theta",if(key!="M3")"kappa","gamma","eta","alpha","zeta",
      "omega","lambda","b0","beta","sigma_u","sigma_v")
  da <- posterior::subset_draws(fit$draws(vars),chain=keep)
  dm <- as.matrix(posterior::as_draws_matrix(da)); S <- nrow(dm)
  replicated <- array(0L,c(S,groups,6L))
  set.seed(20261104L+1000L*match(key,names(MODELS)))
  cat(key,"draws",S,"chains",keep,"\n");flush.console()
  for(i in seq_len(S)) {
    v <- function(nm) as.numeric(dm[i,nm])
    th <- v(sprintf("theta[%d]",s$hh))
    if(key=="M2") {
      eps <- matrix(rnorm(s$T*5L,sd=v("sigma_eps")),s$T,5L)
      x <- matrix(0,nr,6L); nonref <- c(1L,2L,3L,4L,6L)
      for(m in 1:5) x[,nonref[m]] <-
        v(sprintf("icpt[%d,%d,%d]",s$aa,s$cc,m))+
        v(sprintf("slope[%d]",m))*th+eps[s$tt,m]
      x <- exp(x-apply(x,1,max)); p <- x/rowSums(x)
    } else {
      ka <- if(key=="M3")rep(0,nr)else v(sprintf("kappa[%d]",s$hh))
      al <- v(sprintf("alpha[%d,%d]",s$aa,s$cc));b <- v("b0")
      om <- if(key=="M4")v("omega")else v(sprintf("omega[%d]",s$aa))
      pi <- plogis(ka+v(sprintf("gamma[%d,%d]",s$aa,s$cc))+
                     rnorm(nr,sd=v(sprintf("sigma_u[%d]",s$aa))))
      xs0 <- om*th+(1-om)*al-b+rnorm(nr,sd=v(sprintf("sigma_v[%d]",s$aa)))
      ss <- plogis(xs0)
      q <- plogis(th-v(sprintf("eta[%d,%d]",s$aa,s$cc)))
      rho <- plogis(v("lambda")*th-v(sprintf("zeta[%d,%d]",s$aa,s$cc)))
      s1 <- plogis(xs0+v(sprintf("beta[%d,%d]",s$aa,s$cc)))
      p <- tree_probs(pi,q,ss,rho,s1)
    }
    stopifnot(all(is.finite(p)),all(p>=0),max(abs(rowSums(p)-1))<1e-10)
    # Exact multinomial generation via sequential binomials, vectorized over rounds.
    repn <- matrix(0L,nr,6L); remaining <- totals; mass <- rep(1,nr)
    for(m in 1:5) {
      prob <- ifelse(mass>0,p[,m]/mass,0)
      repn[,m] <- rbinom(nr,remaining,pmin(1,pmax(0,prob)))
      remaining <- remaining-repn[,m];mass <- pmax(0,mass-p[,m])
    }
    repn[,6] <- remaining
    stopifnot(all(rowSums(repn)==totals))
    replicated[i,,] <- rowsum(repn,ac,reorder=TRUE)
  }
  tab <- list()
  for(a in 1:s$A)for(cc in 1:s$C)for(m in 1:6) {
    g <- a+s$A*(cc-1L); x <- replicated[,g,m];obs <- observed[g,m]
    tab[[length(tab)+1L]] <- data.frame(model=key,AI=AGENTS[a],density=DENS[cc],
      cell=CELLS[m],n_rounds=ng[g],observed_mean=obs/ng[g],
      predictive_mean=mean(x)/ng[g],PPP=mean(x>=obs),draws=S,
      chains_used=paste(keep,collapse=";"))
  }
  tab <- do.call(rbind,tab);stopifnot(nrow(tab)==60L)
  write.csv(tab,file.path(dest,paste0("ppp_",key,".csv")),row.names=FALSE)
  saveRDS(list(replicated_condition_totals=replicated,observed=observed,
    n_rounds=ng,chains_used=keep,chain_mean_lp=lp),file.path(dest,paste0("replicated_",key,".rds")))
  summaries[[key]] <- data.frame(model=key,PPP_min=min(tab$PPP),PPP_max=max(tab$PPP),
    below_05=sum(tab$PPP<.05),above_95=sum(tab$PPP>.95),n_checks=60L,
    draws=S,chains_used=paste(keep,collapse=";"))
  alltab[[key]] <- tab;print(summaries[[key]]);flush.console()
  rm(fit,dm,da,replicated);gc()
}
write.csv(do.call(rbind,alltab),file.path(dest,"ppp_all_models.csv"),row.names=FALSE)
summary <- do.call(rbind,summaries)
write.csv(summary,file.path(dest,"ppp_summary.csv"),row.names=FALSE)
writeLines(c("Full-data posterior draws, six outcomes, no value effects.",
 "Mixed predictive: new round u,v for trees; new team-by-category effects for M2 shared across rounds.",
 "Observed persons' posterior traits retained. All four chains retained; >= convention, no mid-p ties.",
 "Statistic: mean count per round in each AI x density x category (60/model).",
 "Misfit threshold from manuscript: PPP < .05 or PPP > .95.",
 "No refitting and no cross-validation. Seed=20261104+1000*model_index."),file.path(dest,"METHOD.txt"))
print(summary,row.names=FALSE)
