options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({library(cmdstanr);library(posterior)})
AGENTS <- c("Ignorant","Omit","Divide","Delay","Bottom-Feeder")
DENS <- c(5L,15L)
CELLS <- c("NC_Miss","NC_Human","NC_AI","C_Miss","C_Human","C_AI")
MODELS <- c(M1="M1_hai_trtree",M2="M2_nominal",M3="M3_no_kappa",M4="M4_common_omega")
CHAINS <- 4L
ITER_WARM <- as.integer(Sys.getenv("HAI6NV_WARMUP","1000"))
ITER_SAMP <- as.integer(Sys.getenv("HAI6NV_SAMPLING","1000"))
ADAPT_DELTA <- NULL # Use installed CmdStan default.
MAX_TREEDEPTH <- NULL # Use installed CmdStan default.
SEED <- 20261104L
OUT_DIR <- "output"
dir.create(OUT_DIR,showWarnings=FALSE,recursive=TRUE)
round_key <- function(d) paste(d$fb_id,d$block,d$round,sep="|")
target_key <- function(d) paste(round_key(d),d$ID,sep="|")
softplus <- function(x) pmax(x,0)+log1p(exp(-abs(x)))
tree_probs <- function(pi,q,s0,rho,s1) {
  cbind(pi*(1-s0),pi*s0*rho,pi*s0*(1-rho),
        (1-pi)*(1-s1),(1-pi)*s1*q,(1-pi)*s1*(1-q))
}

