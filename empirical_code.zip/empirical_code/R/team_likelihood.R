# Team-unit marginal likelihood; original code extraction and fixed normal GH.
source("R/00_config.R")
MODEL_TYPE<-c(M1="tree",M2="nominal",M3="tree",M4="tree")
AGENTS<-c("Ignorant","Omit","Divide","Delay","Bottom-Feeder")
DENS<-c(5L,15L)
# Adapted from code/R/likelihood.R: six cells, b0, five-dimensional M2 grid.
# ------------------------------------------------------------------
# Likelihood utilities shared by 02_loo_waic.R and 03_kfold_cv.R
#
# extract_pars()   posterior draws of one fit, as plain arrays, thinned evenly per chain
# round_ll()       tree models: log p(n_r | person values, draw) with the round-level
#                  effects u_r, v_r integrated out by Gauss-Hermite quadrature
# team_ll()        log p(both rounds of each team | person values, draw), all models:
#                    tree models: sum of round_ll() over the team's rounds
#                    M2:          5-D team x cell effects integrated out (GH product grid)
# pointwise_ll()   draws x TEAMS matrix for LOO / WAIC (conditional on person estimates)
# heldout_person_lpd()  log p(all rounds of a new person | draw), integrating the person
#                  effects (and, for M2, the team effects) over their population
#                  distribution (used by K-fold CV)
# Team = person x AI type (2 rounds, one per density); index from team_index() in 00_config.R.
# ------------------------------------------------------------------
.gh_cache<-new.env(parent=emptyenv())
# Standard-normal Gaussian quadrature via the same Jacobi eigenproblem as statmod.
# Avoids requiring installation of an unavailable package; rule unchanged.
gauss.quad.prob<-function(n,dist="normal") {
  stopifnot(dist=="normal",n>=1L);key<-as.character(n)
  if(exists(key,.gh_cache,inherits=FALSE))return(get(key,.gh_cache))
  J<-matrix(0,n,n)
  if(n>1L){J[cbind(seq_len(n-1L),2:n)]<-sqrt(seq_len(n-1L));J<-J+t(J)}
  e<-eigen(J,symmetric=TRUE);o<-order(e$values)
  g<-list(nodes=e$values[o],weights=e$vectors[1,o]^2)
  stopifnot(abs(sum(g$weights)-1)<1e-10,abs(sum(g$nodes*g$weights))<1e-10,
            abs(sum(g$nodes^2*g$weights)-1)<1e-10)
  assign(key,g,.gh_cache);g
}

log_expit <- function(x) -pmax(-x,0)-log1p(exp(-abs(x)))
logadd <- function(a,b) { m<-pmax(a,b); m+log(exp(a-m)+exp(b-m)) }
row_lse <- function(M) {
  if(requireNamespace("matrixStats",quietly=TRUE))return(matrixStats::rowLogSumExps(M))
  m<-apply(M,1,max);m+log(rowSums(exp(M-m)))
}
lse       <- function(x) { m <- max(x); m + log(sum(exp(x - m))) }
multinom_coef <- function(N) lgamma(rowSums(N) + 1) - rowSums(lgamma(N + 1))

# ---- posterior draws as arrays ------------------------------------------------------
extract_pars <- function(fit, key, chains = NULL, n_per_chain = 250, H = NULL) {
  A <- length(AGENTS); C <- length(DENS)
  if (is.null(chains)) chains <- seq_len(fit$num_chains())
  type <- MODEL_TYPE[[key]]
  vars <- if (type == "tree") {
    c("theta", "gamma", "eta", "alpha", "zeta", "omega", "lambda", "sigma_u", "sigma_v",
      "sigma_theta", "b0", "beta", if (key != "M3") c("kappa", "sigma_kappa", "r_theta_kappa"))
  } else c("theta", "sigma_theta", "icpt", "slope", "sigma_eps")
  dm_all <- unclass(as_draws_matrix(subset_draws(fit$draws(vars), chain = chains)))
  n_iter <- nrow(dm_all) / length(chains)
  sel_it <- unique(round(seq(1, n_iter, length.out = min(n_per_chain, n_iter))))
  sel <- as.vector(outer(sel_it, (seq_along(chains) - 1) * n_iter, `+`))
  dm <- dm_all[sel, , drop = FALSE]
  S <- nrow(dm)
  col <- function(nm) dm[, nm]
  vec <- function(nm, n) dm[, sprintf("%s[%d]", nm, seq_len(n)), drop = FALSE]
  mat <- function(nm) {
    out <- array(NA_real_, c(S, A, C))
    for (a in 1:A) for (c in 1:C) out[, a, c] <- dm[, sprintf("%s[%d,%d]", nm, a, c)]
    out
  }
  if (is.null(H)) H <- sum(grepl("^theta\\[", colnames(dm)))
  P <- list(type = type, key = key, S = S, chain_id = rep(seq_along(chains), each = length(sel_it)),
            theta = vec("theta", H), sigma_theta = col("sigma_theta"))
  if (type == "tree") {
    P$sigma_u <- vec("sigma_u", A); P$sigma_v <- vec("sigma_v", A)
    P$gamma <- mat("gamma"); P$eta <- mat("eta"); P$alpha <- mat("alpha"); P$zeta <- mat("zeta")
    P$omega <- if (key == "M4") matrix(col("omega"), S, A) else vec("omega", A)
    P$lambda <- col("lambda"); P$b0 <- col("b0"); P$beta <- mat("beta")
    if (key == "M3") {
      P$kappa <- matrix(0, S, H); P$sigma_kappa <- rep(0, S); P$r <- rep(0, S)
    } else {
      P$kappa <- vec("kappa", H); P$sigma_kappa <- col("sigma_kappa"); P$r <- col("r_theta_kappa")
    }
  } else {
    # icpt[a,c] is a vector[5] in Stan -> columns "icpt[a,c,k]"
    P$icpt <- array(NA_real_, c(S, A, C, 5))
    for (a in 1:A) for (c in 1:C) for (k in 1:5)
      P$icpt[, a, c, k] <- dm[, sprintf("icpt[%d,%d,%d]", a, c, k)]
    P$slope <- vec("slope", 5)
    P$sigma_eps <- col("sigma_eps")
  }
  P
}


round_ll <- function(P,i,N,a,c,th,ka,Q) {
  gh<-gauss.quad.prob(Q,dist="normal");ac<-cbind(a,c)
  xp<-(ka+P$gamma[i,,][ac])+outer(P$sigma_u[i,a],gh$nodes)
  xs<-(P$omega[i,a]*th+(1-P$omega[i,a])*P$alpha[i,,][ac]-P$b0[i])+
       outer(P$sigma_v[i,a],gh$nodes)
  xs1<-xs+P$beta[i,,][ac]
  nc<-rowSums(N[,1:3,drop=FALSE]);cf<-rowSums(N[,4:6,drop=FALSE])
  Au<-nc*log_expit(xp)+cf*log_expit(-xp)
  Bv<-(N[,2]+N[,3])*log_expit(xs)+N[,1]*log_expit(-xs)+
      (N[,5]+N[,6])*log_expit(xs1)+N[,4]*log_expit(-xs1)
  rho<-P$lambda[i]*th-P$zeta[i,,][ac];q<-th-P$eta[i,,][ac]
  fixed<-N[,2]*log_expit(rho)+N[,3]*log_expit(-rho)+
         N[,5]*log_expit(q)+N[,6]*log_expit(-q)
  row_lse(sweep(Au,2,log(gh$weights),`+`))+
  row_lse(sweep(Bv,2,log(gh$weights),`+`))+fixed+multinom_coef(N)
}
gh_grid5<-function(Q) {
  gh<-gauss.quad.prob(Q,dist="normal")
  ix<-as.matrix(expand.grid(rep(list(seq_len(Q)),5L)))
  list(z=matrix(gh$nodes[ix],ncol=5),logw=rowSums(matrix(log(gh$weights)[ix],ncol=5)))
}
# Identical finite product GH grid as code; blocks/matrix products reduce memory.
nominal_team_ll<-function(P,i,d,Q,grid=NULL) {
  if(is.null(grid))grid<-gh_grid5(Q)
  N<-as.matrix(d[,CELLS]);tm<-d$team_id;ac<-cbind(d$a,d$c)
  th<-P$theta[i,d$h];nonref<-c(1,2,3,4,6)
  B<-sapply(1:5,function(m)P$icpt[i,,,m][ac]+P$slope[i,m]*th)
  YT<-rowsum(N[,nonref,drop=FALSE],tm,reorder=TRUE)
  coef<-as.numeric(rowsum(multinom_coef(N)+rowSums(N[,nonref,drop=FALSE]*B),tm,reorder=TRUE))
  off<-pmax(0,apply(B,1,max));EB<-exp(B-off);nt<-rowSums(N)
  result<-rep(-Inf,nrow(YT))
  blocks<-split(seq_len(nrow(grid$z)),ceiling(seq_len(nrow(grid$z))/1024L))
  for(gg in blocks) {
    Z<-P$sigma_eps[i]*grid$z[gg,,drop=FALSE]
    den<-log(tcrossprod(EB,exp(Z))+exp(-off))+off
    L<-coef+tcrossprod(YT,Z)-rowsum(nt*den,tm,reorder=TRUE)
    part<-row_lse(sweep(L,2,grid$logw[gg],`+`))
    result<-logadd(result,part)
  }
  result
}
team_ll<-function(P,i,d,Q,grid=NULL) {
  if(P$key=="M2")return(nominal_team_ll(P,i,d,Q,grid))
  x<-round_ll(P,i,as.matrix(d[,CELLS]),d$a,d$c,P$theta[i,d$h],P$kappa[i,d$h],Q)
  as.numeric(rowsum(x,d$team_id,reorder=TRUE))
}
# Direct original-style reference for checking the blocked nominal implementation.
nominal_reference<-function(P,i,d,Q) {
  g<-gh_grid5(Q);N<-as.matrix(d[,CELLS]);ac<-cbind(d$a,d$c)
  psi<-lapply(1:5,function(m)outer(P$icpt[i,,,m][ac]+P$slope[i,m]*P$theta[i,d$h],P$sigma_eps[i]*g$z[,m],`+`))
  mx<-Reduce(pmax,c(list(matrix(0,nrow(N),nrow(g$z))),psi))
  den<-mx+log(exp(-mx)+Reduce(`+`,lapply(psi,function(x)exp(x-mx))))
  L<--rowSums(N)*den;nonref<-c(1,2,3,4,6)
  for(m in 1:5)L<-L+N[,nonref[m]]*psi[[m]]
  row_lse(sweep(rowsum(L,d$team_id,reorder=TRUE),2,g$logw,`+`))+
    as.numeric(rowsum(multinom_coef(N),d$team_id,reorder=TRUE))
}
