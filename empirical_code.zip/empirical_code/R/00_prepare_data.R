# Data preparation only; called by run_all.R when the user starts the analysis.
# Q1 questionnaire column team is kept separate from model pairing team_id.
csv <- '../data/M1_target6_1108_rounds_with_questionnaire.csv'
d <- read.csv(csv,check.names=FALSE,stringsAsFactors=FALSE,fileEncoding='UTF-8-BOM')
agents <- c('Ignorant','Omit','Divide','Delay','Bottom-Feeder')
densities <- c(5L,15L)
cells <- c('NC_Miss','NC_Human','NC_AI','C_Miss','C_Human','C_AI')
key <- function(x)paste(x$fb_id,x$block,x$round,sep='|')
N <- as.matrix(d[,cells]);storage.mode(N)<-'integer'
stopifnot(nrow(d)==1108L,length(unique(d$fb_id))==277L,
 length(unique(d$team_id))==554L,!anyDuplicated(key(d)),
 all(is.finite(N)),all(N>=0),all(N==as.matrix(d[,cells])),
 sum(N)==180668L,all(rowSums(N)==d$n_spawned),
 identical(as.integer(colSums(N)),c(39438L,42320L,68151L,2576L,19792L,8391L)),
 all(table(d$fb_id)==4L),all(table(d$team_id)==2L),
 all(d$agent_id==match(d$type,agents)),all(d$context_id==match(d$maxTargets,densities)),
 all(d$round_key==key(d)),identical(as.integer(d$round_id),seq_len(nrow(d))))
for(z in list(c('person_id','fb_id'),c('team_id','fb_id','type'))){
 map<-unique(d[,z,drop=FALSE]);stopifnot(!anyDuplicated(map[[1]]))
}
items<-c('team','competent','understand_bot_intent','understand_human_intent',
 'human_contributed_more','easy_to_play_with','fun_to_play_with','similar_playing_style')
stopifnot(!anyNA(d[,c(items,'SelectedRobot')]))
d$r<-as.integer(d$round_id);d$h<-as.integer(d$person_id)
d$a<-as.integer(d$agent_id);d$c<-as.integer(d$context_id)
stopifnot(setequal(d$h,1:277),setequal(d$team_id,1:554))
s<-list(R=nrow(d),H=277L,A=5L,C=2L,T=554L,
 hh=d$h,aa=d$a,cc=d$c,tt=as.integer(d$team_id),n=unname(N))
x<-list(stan=s,rounds=d,cells=cells,agents=agents,densities=densities,
 provenance=list(csv=normalizePath(csv),csv_md5=unname(tools::md5sum(csv)),
 reconstructed_rounds=5L,original_rounds=1103L))
dir.create('data',showWarnings=FALSE)
saveRDS(x,'data/prepared_data.rds')
cat('Prepared 277 persons, 554 teams, 1108 rounds, 180668 targets from new CSV.\n')
