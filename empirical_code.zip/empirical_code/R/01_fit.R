source("R/00_config.R")
x <- readRDS("data/prepared_data.rds"); s <- x$stan
stopifnot(sum(s$n)==180668L,s$R==1108L,ncol(s$n)==6L)
# Orthonormal contrasts ensure sum(alpha)=0, with symmetric marginal N(0,2) prior.
s$alpha_basis <- unname(qr.Q(qr(contr.helmert(s$A*s$C))))
stopifnot(max(abs(colSums(s$alpha_basis)))<1e-10,
          max(abs(crossprod(s$alpha_basis)-diag(s$A*s$C-1L)))<1e-10)
x$stan <- s;saveRDS(x,"output/prepared_data.rds")
set.seed(SEED)
errors <- numeric(200)
for(i in seq_along(errors)) {
  logits <- rnorm(5);p <- as.numeric(tree_probs(plogis(logits[1]),plogis(logits[2]),
                       plogis(logits[3]),plogis(logits[4]),plogis(logits[5])))
  stopifnot(all(p>0),abs(sum(p)-1)<1e-12)
  n <- as.numeric(rmultinom(1,150,p));nc<-sum(n[1:3]);cf<-sum(n[4:6])
  kern <- function(y,N,l) dbinom(y,N,plogis(l),log=TRUE)-lchoose(N,y)
  ll <- kern(nc,sum(n),logits[1])+kern(sum(n[2:3]),nc,logits[3])+
    kern(n[2],sum(n[2:3]),logits[4])+kern(sum(n[5:6]),cf,logits[5])+
    kern(n[5],sum(n[5:6]),logits[2])
  errors[i]<-abs(ll-sum(n*log(p)))
}
stopifnot(max(errors)<1e-9)
writeLines(paste("200 random probability/kernel checks passed; max error",max(errors)),
           "output/pre_fit_validation.txt")
exe <- setNames(character(length(MODELS)),names(MODELS))
for(key in names(MODELS)) {
  cat("Compile",key,"\n");flush.console()
  exe[key] <- cmdstan_model(file.path("stan",paste0(MODELS[[key]],".stan")))$exe_file()
}
fit_one <- function(key,root,exe,s) {
  setwd(root);source("R/00_config.R")
  dest<-file.path("output",key);dir.create(dest,recursive=TRUE,showWarnings=FALSE)
  if(file.exists(file.path(dest,"COMPLETE.txt")))return(read.csv(file.path(dest,"fit_diagnostics.csv")))
  t0<-Sys.time();cat(format(t0),"Start",key,"\n");flush.console()
  rate<-function(y,n)qlogis((y+.5)/(n+1))
  nac<-rowsum(s$n,s$aa+s$A*(s$cc-1L));mu0<-rate(rowSums(nac[,2:3]),rowSums(nac[,1:3]))
  mu1<-rate(rowSums(nac[,5:6]),rowSums(nac[,4:6]));b_init<--mean(mu0)
  init<-function(chain_id) {
    set.seed(SEED+100L*match(key,names(MODELS))+chain_id)
    jit<-function(z)z+rnorm(length(z),0,.03)
    if(key=="M2") {
      ix<-c(1,2,3,4,6);ic<-array(0,c(s$A,s$C,5))
      for(m in 1:5)ic[,,m]<-matrix(log((nac[,ix[m]]+.5)/(nac[,5]+.5)),s$A,s$C)
      return(list(z_theta=rnorm(s$H,0,.03),sigma_theta=.3,icpt=ic,
        slope_free=rep(.1,4),z_eps=matrix(rnorm(s$T*5,0,.03),s$T,5),sigma_eps=.3))
    }
    z<-list(sigma_theta=.5,gamma=matrix(jit(rate(rowSums(nac[,1:3]),rowSums(nac))),s$A,s$C),
      eta=matrix(jit(-rate(nac[,5],rowSums(nac[,5:6]))),s$A,s$C),
      alpha_z=as.numeric(crossprod(s$alpha_basis,(mu0-mean(mu0))/.7)),
      beta=matrix(jit(mu1-mu0),s$A,s$C),
      zeta=matrix(jit(-rate(nac[,2],rowSums(nac[,2:3]))),s$A,s$C),
      omega=if(key=="M4").3 else rep(.3,s$A),lambda=.5,b0=b_init,
      z_u=rnorm(s$R,0,.03),z_v=rnorm(s$R,0,.03),sigma_u=rep(.3,s$A),sigma_v=rep(.3,s$A))
    if(key=="M3") z$z_theta<-rnorm(s$H,0,.03) else {
      z$z_person<-matrix(rnorm(2*s$H,0,.03),2,s$H);z$L_person<-diag(2);z$sigma_kappa<-.3
    }
    z
  }
  model<-cmdstan_model(exe_file=exe[[key]],compile=FALSE)
  fit<-model$sample(data=s,chains=CHAINS,parallel_chains=CHAINS,
    iter_warmup=ITER_WARM,iter_sampling=ITER_SAMP,seed=SEED+match(key,names(MODELS)),
    init=init,adapt_delta=ADAPT_DELTA,max_treedepth=MAX_TREEDEPTH,
    refresh=100,output_dir=normalizePath(dest,winslash="/"))
  fit$save_object(file.path(dest,"fit.rds"))
  vars<-if(key=="M2")c("sigma_theta","sigma_eps","icpt","slope","theta")else
    c("sigma_theta",if(key!="M3")c("sigma_kappa","r_theta_kappa","kappa"),
      "gamma","eta","alpha","beta","zeta","omega","lambda","b0","sigma_u","sigma_v","theta")
  write.csv(fit$summary(vars,"mean","sd",q025=function(x)unname(quantile(x,.025)),
    q975=function(x)unname(quantile(x,.975)),"rhat","ess_bulk","ess_tail"),
    file.path(dest,"parameter_summary.csv"),row.names=FALSE)
  av<-setdiff(fit$metadata()$stan_variables,c("n_rep_ac","log_lik_round","xpi","xq","xs","xs1","xrho","base"))
  d<-fit$summary(av,c("rhat","ess_bulk","ess_tail"))
  write.csv(d,file.path(dest,"all_parameter_diagnostics.csv"),row.names=FALSE)
  ds<-fit$diagnostic_summary(quiet=TRUE);write.csv(ds,file.path(dest,"sampler_diagnostics.csv"),row.names=FALSE)
  lp<-apply(fit$draws("lp__",format="draws_array"),2,mean)
  ans<-data.frame(model=key,minutes=as.numeric(difftime(Sys.time(),t0,units="mins")),
    max_rhat=max(d$rhat,na.rm=TRUE),min_bulk_ess=min(d$ess_bulk,na.rm=TRUE),
    min_tail_ess=min(d$ess_tail,na.rm=TRUE),divergences=sum(ds$num_divergent),
    max_treedepth_hits=sum(ds$num_max_treedepth),min_ebfmi=min(ds$ebfmi),
    chains=CHAINS,warmup=ITER_WARM,sampling=ITER_SAMP,chain_mean_lp=paste(round(lp,2),collapse=";"))
  write.csv(ans,file.path(dest,"fit_diagnostics.csv"),row.names=FALSE)
  writeLines(format(Sys.time()),file.path(dest,"COMPLETE.txt"));ans
}
cl<-parallel::makePSOCKcluster(4,outfile="output/worker_log.txt")
ans<-tryCatch(parallel::parLapplyLB(cl,names(MODELS),fit_one,root=getwd(),exe=exe,s=s),
  finally=parallel::stopCluster(cl))
write.csv(do.call(rbind,ans),"output/fit_diagnostics.csv",row.names=FALSE)
print(do.call(rbind,ans),row.names=FALSE)
