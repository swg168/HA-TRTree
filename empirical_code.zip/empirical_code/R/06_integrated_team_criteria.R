# Same estimand as code/R/02_loo_waic.R: condition on persons, integrate lower effects.
source("R/team_likelihood.R")
suppressPackageStartupMessages(library(loo))
dest<-"output/integrated_team_criteria";dir.create(dest,recursive=TRUE,showWarnings=FALSE)
x<-readRDS("output/prepared_data.rds");s<-x$stan;d<-x$rounds
d[,CELLS]<-s$n;d$a<-s$aa;d$c<-s$cc;d$h<-s$hh;d$team_id<-s$tt
stopifnot(length(unique(d$team_id))==554L,s$H==277L)
loos<-waics<-list();settings<-list();pilots<-list()
for(key in names(MODELS)) {
  cat(format(Sys.time()),key,"extract original-rule draws\n");flush.console()
  pf<-file.path(dest,paste0(key,"_pars.rds"))
  if(file.exists(pf))P<-readRDS(pf)else {
    fit<-readRDS(file.path("output",key,"fit.rds"))
    lp<-apply(fit$draws("lp__",format="draws_array"),2,mean)
    keep<-which(lp>max(lp)-20)
    P<-extract_pars(fit,key,chains=keep,n_per_chain=250L)
    P$original_chain_ids<-keep
    saveRDS(P,pf);rm(fit);gc()
  }
  # Fixed-GH resolution screening; no posterior, likelihood, or prior changes.
  ids<-unique(round(seq(1,P$S,length.out=12L)))
  dp<-d
  if(key=="M2") {
    ids<-unique(c(ids,which.max(P$sigma_eps)))
    ts<-sort(unique(d$team_id));use<-ts[unique(round(seq(1,length(ts),length.out=32L)))]
    nt<-tapply(rowSums(as.matrix(d[,CELLS])),d$team_id,sum)
    for(a in unique(d$a)) {
      tt<-unique(d$team_id[d$a==a]);use<-union(use,tt[which.max(nt[as.character(tt)])])
    }
    dp<-d[d$team_id%in%use,];dp$team_id<-match(dp$team_id,sort(unique(dp$team_id)))
    err<-max(abs(nominal_reference(P,ids[1],dp,4L)-nominal_team_ll(P,ids[1],dp,4L)))
    stopifnot(err<1e-8)
    cat("M2 blocked vs original grid max error",err,"\n");flush.console()
  }
  qs<-if(key=="M2")c(4L,6L,8L,10L,12L)else c(9L,17L,33L,65L,129L)
  eval_pilot<-function(Q) {
    grid<-if(key=="M2")gh_grid5(Q)else NULL
    t(vapply(ids,function(i)team_ll(P,i,dp,Q,grid),numeric(length(unique(dp$team_id)))))
  }
  previous<-eval_pilot(qs[1]);chosen<-NA_integer_;history<-list()
  for(j in 2:length(qs)) {
    current<-eval_pilot(qs[j]);delta<-max(abs(current-previous))
    history[[length(history)+1L]]<-data.frame(model=key,Q_low=qs[j-1],Q_high=qs[j],
      max_abs_loglik_diff=delta,n_draws=length(ids),n_teams=ncol(current),tolerance=.002)
    cat(key,"GH",qs[j-1],"vs",qs[j],"max team loglik diff",delta,"\n");flush.console()
    if(delta<.002){chosen<-qs[j-1];break}
    previous<-current
  }
  pilots[[key]]<-do.call(rbind,history)
  write.csv(do.call(rbind,pilots),file.path(dest,"quadrature_pilot.csv"),row.names=FALSE)
  if(is.na(chosen))stop("GH screening did not stabilize for ",key,"; results not finalized")
  settings[[key]]<-data.frame(model=key,Q=chosen,draws=P$S,
    chains=paste(P$original_chain_ids,collapse=";"),pilot_max_diff=delta)
  ckdir<-file.path(dest,paste0(key,"_Q",chosen));dir.create(ckdir,showWarnings=FALSE)
  chunks<-split(seq_len(P$S),ceiling(seq_len(P$S)/10L))
  cat(format(Sys.time()),key,"full team scoring; Q=",chosen,"; draws=",P$S,"\n");flush.console()
  cl<-parallel::makePSOCKcluster(24,outfile=file.path(dest,"worker_log.txt"))
  mats<-tryCatch(parallel::parLapplyLB(cl,seq_along(chunks),function(j,chunks,P,d,Q,root,ckdir) {
    setwd(root);source("R/team_likelihood.R")
    f<-file.path(ckdir,sprintf("chunk%03d.rds",j));if(file.exists(f))return(readRDS(f))
    grid<-if(P$key=="M2")gh_grid5(Q)else NULL
    out<-t(vapply(chunks[[j]],function(i)team_ll(P,i,d,Q,grid),numeric(length(unique(d$team_id)))))
    stopifnot(all(is.finite(out)));saveRDS(out,f)
    cat(format(Sys.time()),P$key,"chunk",j,"complete\n");flush.console();out
  },chunk.size=1L,chunks=chunks,P=P,d=d,Q=chosen,root=getwd(),ckdir=ckdir),finally=parallel::stopCluster(cl))
  ll<-do.call(rbind,mats);stopifnot(identical(dim(ll),c(P$S,554L)))
  saveRDS(ll,file.path(dest,paste0(key,"_loglik_team.rds")))
  reff<-loo::relative_eff(exp(sweep(ll,2,apply(ll,2,max),"-")),chain_id=P$chain_id)
  waics[[key]]<-loo::waic(ll);loos[[key]]<-loo::loo(ll,r_eff=reff,cores=4)
  saveRDS(list(loo=loos[[key]],waic=waics[[key]],settings=settings[[key]]),file.path(dest,paste0(key,"_criteria.rds")))
  cat(format(Sys.time()),key,"WAIC",waics[[key]]$estimates["waic",1],
    "LOOIC",loos[[key]]$estimates["looic",1],"k>.7",sum(loo::pareto_k_values(loos[[key]])>.7),"/554\n");flush.console()
}
cmp<-as.data.frame(loo::loo_compare(loos));if(!"model"%in%names(cmp))cmp$model<-rownames(cmp)
write.csv(cmp,file.path(dest,"loo_compare.csv"),row.names=FALSE)
tab<-do.call(rbind,lapply(names(MODELS),function(key) {
  k<-loo::pareto_k_values(loos[[key]]);l<-loos[[key]]$estimates;w<-waics[[key]]$estimates
  data.frame(model=key,WAIC=w["waic",1],LOOIC=l["looic",1],elpd_diff=cmp$elpd_diff[match(key,cmp$model)],
    se_diff=cmp$se_diff[match(key,cmp$model)],k_gt_07=sum(k>.7),k_gt_07_percent=100*mean(k>.7),
    k_gt_1=sum(k>1),max_k=max(k),waic_variance_gt_04=sum(waics[[key]]$pointwise[,"p_waic"]>.4),n_teams=554L)
}))
tab<-tab[order(tab$LOOIC),];write.csv(tab,file.path(dest,"comparison.csv"),row.names=FALSE)
write.csv(do.call(rbind,settings),file.path(dest,"settings.csv"),row.names=FALSE)
saveRDS(list(loo=loos,waic=waics,loo_compare=cmp),file.path(dest,"objects.rds"))
writeLines(c("Original code estimand: conditional on persons, integrate round u/v (trees), team-by-cell effects (M2); one point per 554 teams.",
 "Original good_chains mean-lp tolerance 20, 250 evenly spaced draws per selected chain.",
 "Same fixed normal Gauss-Hermite rule. Resolution starts at original 9 (trees), 4 (nominal), increased if finite-screen differences exceed .002 per team/draw.",
 "See quadrature_pilot.csv: pilot screening is finite, not an exhaustive accuracy guarantee for every draw/team. Full likelihood checkpoints retained.",
 "Shared round v is integrated jointly over the two interception branches. M2 five-dimensional grid replaces original four-dimensional grid because there are six categories.",
 "No refitting. LOO comparisons remain team-unit and retain person parameters; not new-person K-fold scores. Check Pareto k and original fit diagnostics."),file.path(dest,"METHOD.txt"))
print(tab,row.names=FALSE);print(cmp);cat("DONE\n")
