source('sim/run_helpers.R')
for(f in c(list.files('sim',pattern='\\.R$',full.names=TRUE),'run_simulation.R'))parse(f)
stopifnot(nrow(DESIGN)==19L,N_REPS==50L)
gen<-readRDS(GEN_FILE)
set.seed(101);max_kernel_error<-0
for(i in seq_len(nrow(DESIGN))){
 par<-condition_parameters(gen,DESIGN[i,]);s<-simulate_dataset(par,20L,DESIGN$K[i],100+i)
 stopifnot(ncol(s$data$n)==6L,s$data$R==80L*DESIGN$K[i],
   all(rowSums(s$data$n)>0),abs(sum(par$alpha))<1e-9,
   max(abs(crossprod(s$data$alpha_basis)-diag(ncol(s$data$alpha_basis))))<1e-10,
   max(abs(colSums(s$data$alpha_basis)))<1e-10)
 if(!is.na(DESIGN$conflict[i]))stopifnot(abs(par$expected_conflict-DESIGN$conflict[i])<1e-6)
 tv<-truth_vector(par,s$truth);stopifnot(!anyNA(tv),all(is.finite(tv)))
 # Verify the five-binomial Stan kernel equals the six-category multinomial
 # kernel up to the multinomial coefficient for an arbitrary predictor vector.
 for(k in 1:10){
  x<-rnorm(5);p<-plogis(x);pi<-p[1];s0<-p[2];s1<-p[3];rho<-p[4];q<-p[5]
  pp<-c(pi*(1-s0),pi*s0*rho,pi*s0*(1-rho),(1-pi)*(1-s1),(1-pi)*s1*q,(1-pi)*s1*(1-q))
  n<-as.vector(rmultinom(1,130,pp));nc<-sum(n[1:3]);ct<-sum(n[4:6])
  kern<-function(y,N,l)dbinom(y,N,plogis(l),log=TRUE)-lchoose(N,y)
  ll<-kern(nc,sum(n),x[1])+kern(sum(n[2:3]),nc,x[2])+kern(n[2],sum(n[2:3]),x[4])+
    kern(sum(n[5:6]),ct,x[3])+kern(n[5],sum(n[5:6]),x[5])
  max_kernel_error<-max(max_kernel_error,abs(ll-sum(n*log(pp))))
 }
}
stopifnot(max_kernel_error<1e-9)
writeLines(c('PREFLIGHT PASSED: all 19 design conditions, zero-sum alpha, preservation of efficacy after reanchoring, six probabilities, target counts and conflict calibration.',
 paste('Maximum kernel error:',format(max_kernel_error,digits=12))),'sim/PREFLIGHT_PASSED.txt')
stamp('PREFLIGHT PASSED; max kernel error',max_kernel_error)
