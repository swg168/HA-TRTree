source('sim/run_helpers.R')
main<-function(){
stopifnot(.Platform$OS.type=='unix')
args<-commandArgs(trailingOnly=TRUE)
smoke<-'smoke'%in%args
if(smoke){SIM_OUT<<-'sim_output_smoke';SIM_CHAINS<<-2L;SIM_ITER_WARM<<-150L;SIM_ITER_SAMP<<-150L}
dir.create(SIM_OUT,recursive=TRUE,showWarnings=FALSE)
lock<-file.path(SIM_OUT,'RUN_LOCK')
if(!dir.create(lock,showWarnings=FALSE))stop('RUN_LOCK exists; another controller may be active. Inspect before resuming.')
on.exit(unlink(lock,recursive=TRUE),add=TRUE)
writeLines(as.character(Sys.getpid()),file.path(lock,'pid'))
MODEL_FINGERPRINT<<-paste(unname(tools::md5sum(c(STAN_SIM,GEN_FILE,'sim/sim_functions.R','sim/run_helpers.R'))),collapse=':')
exe<-cmdstan_model(STAN_SIM)$exe_file()
writeLines(exe,file.path(SIM_OUT,'compiled_executable.txt'))
gen<-readRDS(GEN_FILE);pars<-lapply(seq_len(nrow(DESIGN)),function(i)condition_parameters(gen,DESIGN[i,]))
if(smoke){
 cond<-DESIGN[DESIGN$H==277&DESIGN$K==1&DESIGN$A==5&is.na(DESIGN$conflict),]
 cond$H<-20L
 f<-run_replication(cond,1L,condition_parameters(gen,cond),exe)
 stamp('SMOKE COMPLETE:',f);return(invisible(f))
}
expected<-expand.grid(cond_id=DESIGN$cond_id,rep=seq_len(N_REPS))
tasks<-lapply(seq_len(nrow(expected)),function(i){e<-expected[i,];list(cond=DESIGN[e$cond_id,],rep=e$rep)})
tasks<-tasks[order(-vapply(tasks,function(x)x$cond$H*x$cond$K,0))]
pending<-Filter(function(t){f<-rep_file(t$cond$cond_id,t$rep);if(!file.exists(f))return(TRUE)
 x<-readRDS(f);stopifnot(identical(x$model_fingerprint,MODEL_FINGERPRINT));FALSE},tasks)
maxfits<-min(N_PARALLEL_SIMS,23L);reserve<-4L;ncores<-parallel::detectCores()
writeLines(c(paste('controller_pid',Sys.getpid()),paste('max_parallel_fits',maxfits),
 paste('chains_per_fit',SIM_CHAINS),paste('expected_replications',nrow(expected))),file.path(SIM_OUT,'RUN_STARTED.txt'))
running<-list();failed<-list();next_task<-1L;finished<-nrow(expected)-length(pending);last_report<-Sys.time()-60
stamp('START',length(pending),'remaining fits; maximum',maxfits,'fits x',SIM_CHAINS,'chains; load-adaptive scheduling')
repeat{
 if(length(running)){
  collected<-parallel::mccollect(lapply(running,`[[`,'job'),wait=FALSE)
  if(length(collected))for(pid in names(collected)){
   v<-collected[[pid]];t<-running[[pid]]$task
   if(inherits(v,'try-error')||!is.list(v)||!isTRUE(v$ok)){
    msg<-if(is.list(v)&&!is.null(v$message))v$message else as.character(v)
    err<-list(cond_id=t$cond$cond_id,rep=t$rep,message=msg,time=as.character(Sys.time()))
    failed[[length(failed)+1]]<-err
    atomic_rds(err,file.path(SIM_OUT,sprintf('ERROR_cond%02d_rep%03d.rds',t$cond$cond_id,t$rep)))
    stamp('FAILED',t$cond$cond_id,t$rep,msg)
   }else {finished<-finished+1L;stamp('COMPLETE',t$cond$cond_id,t$rep,'saved',finished,'/',nrow(expected))}
   running[[pid]]<-NULL
  }
 }
 if(next_task>length(pending)&&!length(running))break
 # Estimate other work from the one-minute load, allowing for our active chains.
 # Launching adapts to released capacity; already running fits are never killed.
 load1<-as.numeric(strsplit(readLines('/proc/loadavg',n=1),' ')[[1]][1])
 other<-max(0,load1-SIM_CHAINS*length(running))
 capacity<-max(1L,min(maxfits,as.integer(floor((ncores-reserve-other)/SIM_CHAINS))))
 while(next_task<=length(pending)&&length(running)<capacity){
  task<-pending[[next_task]];next_task<-next_task+1L
  job<-parallel::mcparallel(tryCatch({run_replication(task$cond,task$rep,pars[[task$cond$cond_id]],exe);list(ok=TRUE)},
   error=function(e)list(ok=FALSE,message=conditionMessage(e))),mc.set.seed=FALSE,silent=TRUE)
  running[[as.character(job$pid)]]<-list(job=job,task=task)
  stamp('LAUNCH',task$cond$cond_id,task$rep,'pid',job$pid,'active',length(running),'capacity',capacity)
 }
 if(as.numeric(difftime(Sys.time(),last_report,units='secs'))>=30){
  write.csv(data.frame(timestamp=as.character(Sys.time()),completed=finished,expected=nrow(expected),
   failed=length(failed),active_fits=length(running),active_chain_slots=SIM_CHAINS*length(running),
   capacity=capacity,load1=load1),file.path(SIM_OUT,'progress.csv'),row.names=FALSE)
  last_report<-Sys.time()
 }
 Sys.sleep(10)
}
allfiles<-vapply(tasks,function(t)rep_file(t$cond$cond_id,t$rep),'')
if(length(failed)||!all(file.exists(allfiles))){
 writeLines(c(as.character(Sys.time()),paste('successful',sum(file.exists(allfiles)),'of',nrow(expected)),
  paste('failures',length(failed))),file.path(SIM_OUT,'RUN_FINISHED_WITH_ERRORS.txt'))
 stop('Run ended with failed or missing fits; inspect ERROR files. No SIMULATION_COMPLETE marker written.')
}
stamp('All',nrow(expected),'replications saved. Summarising original recovery metrics.')
status<-system2(file.path(R.home('bin'),'Rscript'),c('--vanilla','sim/03_summarise.R'))
stopifnot(status==0L)
write.csv(data.frame(timestamp=as.character(Sys.time()),completed=nrow(expected),expected=nrow(expected),
 failed=0L,active_fits=0L),file.path(SIM_OUT,'progress.csv'),row.names=FALSE)
writeLines(c('SIMULATION COMPLETE',as.character(Sys.time()),'950 of 950 replication RDS files verified; recovery and convergence summaries written.',
 'Completion indicates finished computation, not that all fits passed convergence diagnostics.'),file.path(SIM_OUT,'SIMULATION_COMPLETE.txt'))
unlink(lock,recursive=TRUE)
stamp('SIMULATION COMPLETE: 950/950. Marker:',file.path(SIM_OUT,'SIMULATION_COMPLETE.txt'))
}
main()
