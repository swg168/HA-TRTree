# ------------------------------------------------------------------
# Simulation study for M1 (HAI-TRTree): settings and design grid.
# Every simulation script starts with source("sim/sim_config.R") from the project root.
# ------------------------------------------------------------------

suppressPackageStartupMessages({
  library(cmdstanr)
  library(posterior)
})

# ---- settings you are likely to change ---------------------------
SIM_DIR        <- "sim"
SIM_OUT        <- Sys.getenv("HAI_SIM_OUT", "sim_output")            # one .rds per (condition, replication)
GEN_FILE       <- file.path(SIM_DIR, "generating_values_M1.rds")
STAN_SIM       <- file.path("stan", "M1_hai_trtree.stan")   # fitted with do_ppc = 0

N_REPS         <- 50       # replications per condition
N_PARALLEL_SIMS <- as.integer(Sys.getenv("HAI_SIM_MAX_FITS", "23"))       # replications fitted at the same time
SIM_CHAINS     <- 4        # chains per fit (all run in parallel)
SIM_ITER_WARM  <- 1000
SIM_ITER_SAMP  <- 1000
SIM_ADAPT_DELTA <- NULL # Use installed CmdStan default.
SIM_MAX_TREEDEPTH <- NULL # Use installed CmdStan default.
SIM_SEED_BASE  <- 20261018
# CPU cores used at peak = N_PARALLEL_SIMS x SIM_CHAINS (default 4 x 4 = 16).
# Temporary disk per running fit: up to ~1 GB for the largest condition (H = 500, K = 3);
# the CmdStan CSV files are deleted as soon as each fit has been summarised.

# Quick end-to-end test (results NOT for reporting): HAI_SIM_QUICK=1
if (Sys.getenv("HAI_SIM_QUICK") == "1") {
  N_REPS <- 1; SIM_CHAINS <- 2; SIM_ITER_WARM <- 150; SIM_ITER_SAMP <- 150
  N_PARALLEL_SIMS <- 2; SIM_OUT <- "sim_output_quick"
}
if (nzchar(Sys.getenv("CMDSTAN"))) set_cmdstan_path(Sys.getenv("CMDSTAN"))
# ------------------------------------------------------------------

# ---- design grid ---------------------------------------------------
# Baseline = empirical design: H = 277, K = 1 (each person plays 2 AIs x 2 densities x K
# rounds = 4 rounds), A = 5, conflict at the empirical level (conflict = NA: no shift).
#  S1  sample size x test length : H {100, 277, 500} x K {1, 2, 3}
#  S2  conflict prevalence       : conflict {2%, 5%, empirical, 30%} x H {100, 277}
#  S3  number of AI types        : A {2, 5, 10} x H {100, 277}
build_design <- function() {
  s1 <- expand.grid(H = c(100, 277, 500), K = 1:3, A = 5, conflict = NA_real_)
  s1$substudy <- "S1"
  s2 <- expand.grid(H = c(100, 277), K = 1, A = 5, conflict = c(0.02, 0.05, NA, 0.30))
  s2$substudy <- "S2"
  s3 <- expand.grid(H = c(100, 277), K = 1, A = c(2, 5, 10), conflict = NA_real_)
  s3$substudy <- "S3"
  all <- rbind(s1, s2, s3)
  key <- paste(all$H, all$K, all$A, ifelse(is.na(all$conflict), "emp", all$conflict))
  sub <- tapply(all$substudy, key, function(x) paste(sort(unique(x)), collapse = ";"))
  des <- all[!duplicated(key), c("H", "K", "A", "conflict")]
  des$substudy <- as.vector(sub[key[!duplicated(key)]])
  des <- des[order(des$A, des$H, des$K, is.na(des$conflict), des$conflict), ]
  des$cond_id <- seq_len(nrow(des))
  rownames(des) <- NULL
  des[, c("cond_id", "substudy", "H", "K", "A", "conflict")]
}
DESIGN <- build_design()

rep_file <- function(cond_id, rep) file.path(SIM_OUT, sprintf("cond%02d_rep%03d.rds", cond_id, rep))
dir.create(SIM_OUT, showWarnings = FALSE, recursive = TRUE)
