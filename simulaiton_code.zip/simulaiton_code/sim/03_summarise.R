# ------------------------------------------------------------------
# Step 3: summarise parameter recovery over replications.
# Per replication and parameter group: bias, RMSE, correlation of estimates with true
# values (groups with > 2 elements), 95% interval coverage, mean posterior SD.
# These are then averaged over replications within each condition.
# Usage: Rscript sim/03_summarise.R
# Output: sim_output/recovery_by_condition.csv, sim_output/convergence_by_condition.csv
# ------------------------------------------------------------------
source("sim/sim_config.R")

files <- list.files(SIM_OUT, pattern = "^cond\\d+_rep\\d+\\.rds$", full.names = TRUE)
stopifnot(length(files) > 0)
res <- lapply(files, readRDS)

per_rep <- do.call(rbind, lapply(res, function(x) {
  e <- x$est
  do.call(rbind, lapply(split(e, e$group), function(g) {
    err <- g$mean - g$true
    data.frame(cond_id = x$cond_id, rep = x$rep, group = g$group[1], n_elem = nrow(g),
               bias = mean(err), rmse = sqrt(mean(err^2)),
               cor = if (nrow(g) > 2 && sd(g$true) > 0) cor(g$mean, g$true) else NA_real_,
               coverage = mean(g$true >= g$`q2.5` & g$true <= g$`q97.5`),
               post_sd = mean(g$sd))
  }))
}))

agg <- aggregate(cbind(bias, rmse, cor, coverage, post_sd) ~ cond_id + group,
                 data = per_rep, FUN = mean, na.action = na.pass)
nrep <- aggregate(rep ~ cond_id + group, data = per_rep, FUN = length)
names(nrep)[3] <- "n_reps"
agg <- merge(merge(DESIGN, agg, by = "cond_id"), nrep, by = c("cond_id", "group"))
group_order <- c("theta", "kappa", "gamma", "eta", "alpha", "zeta", "ai_contrib", "omega", "lambda",
                 "sigma_theta", "sigma_kappa", "r_theta_kappa", "sigma_u", "sigma_v", "beta", "b0", "lambda_std")
agg <- agg[order(agg$cond_id, match(agg$group, group_order)), ]
num <- c("bias", "rmse", "cor", "coverage", "post_sd")
agg[num] <- lapply(agg[num], round, 3)
write.csv(per_rep, file.path(SIM_OUT,"recovery_per_rep.csv"),row.names=FALSE)
write.csv(diag <- do.call(rbind,lapply(res,`[[`,"diag")),file.path(SIM_OUT,"diagnostics_per_rep.csv"),row.names=FALSE)
write.csv(agg, file.path(SIM_OUT, "recovery_by_condition.csv"), row.names = FALSE)

diag <- do.call(rbind, lapply(res, `[[`, "diag"))
conv <- do.call(rbind, lapply(split(diag, diag$cond_id), function(d) data.frame(
  cond_id = d$cond_id[1], n_reps = nrow(d),
  prop_converged = mean(d$max_rhat < 1.01 & d$divergences == 0),
  prop_rhat_ok = mean(d$max_rhat < 1.01), mean_divergences = mean(d$divergences),
  mean_realized_conflict = mean(d$realized_conflict), mean_minutes = mean(d$minutes))))
conv <- merge(DESIGN, conv, by = "cond_id")
conv[, 7:12] <- lapply(conv[, 7:12], round, 3)
write.csv(conv, file.path(SIM_OUT, "convergence_by_condition.csv"), row.names = FALSE)

print(conv, row.names = FALSE)
cat("\nRecovery (first condition shown; full table in recovery_by_condition.csv):\n")
print(agg[agg$cond_id == min(agg$cond_id), c("group", num, "n_reps")], row.names = FALSE)
