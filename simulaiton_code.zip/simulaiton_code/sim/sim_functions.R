# ------------------------------------------------------------------
# Simulation functions for M1 (HAI-TRTree)
#   extract_generating_values() : posterior means of the empirical M1 fit
#   make_agents()               : AI-level parameters for A = 2 / 5 / 10
#   expected_conflict(), conflict_shift() : calibrate the overall conflict proportion
#   condition_parameters()      : full generating parameter set for one condition
#   simulate_dataset()          : one simulated data set + true values
#   run_replication()           : simulate -> fit M1 -> summarise -> save
# ------------------------------------------------------------------

DENS_N <- 2   # number of densities (contexts)

# ---- generating values from the empirical M1 fit ---------------------------
extract_generating_values <- function(fit, rounds) {
  A <- 5; C <- DENS_N
  pm <- function(v) colMeans(as_draws_matrix(fit$draws(v)))
  mat <- function(v) {
    x <- pm(v)
    outer(1:A, 1:C, Vectorize(function(a, c) x[[sprintf("%s[%d,%d]", v, a, c)]]))
  }
  vec <- function(v) unname(pm(v)[sprintf("%s[%d]", v, 1:A)])
  list(
    sigma_theta = unname(pm("sigma_theta")), sigma_kappa = unname(pm("sigma_kappa")),
    r = unname(pm("r_theta_kappa")), lambda = unname(pm("lambda")),
    omega = vec("omega"), sigma_u = vec("sigma_u"), sigma_v = vec("sigma_v"),
    gamma = mat("gamma"), eta = mat("eta"), alpha = mat("alpha"), zeta = mat("zeta"),
    beta = mat("beta"), b0 = unname(pm("b0")),
    agents = c("Ignorant", "Omit", "Divide", "Delay", "Bottom-Feeder"),
    # empirical numbers of spawned targets per round, by density (resampled in simulation)
    N_spawned = list(rounds$n_spawned[rounds$maxTargets == 5],
                     rounds$n_spawned[rounds$maxTargets == 15]))
}

# ---- AI-level parameters for A = 2, 5 or 10 ----------------------------------
# A = 2  : Ignorant and Omit (largest contrast in the contest node)
# A = 5  : the five empirical agents
# A = 10 : five empirical agents + five synthetic variants (each empirical agent's
#          parameters perturbed by N(0, 0.3) on the logit / log scale; fixed seed)
make_agents <- function(gen, A, synth_sd = 0.3, synth_seed = 999) {
  keep <- switch(as.character(A), "2" = 1:2, "5" = 1:5, "10" = 1:5,
                 stop("A must be 2, 5 or 10"))
  ag <- list(gamma = gen$gamma[keep, , drop = FALSE], eta = gen$eta[keep, , drop = FALSE],
             alpha = gen$alpha[keep, , drop = FALSE], zeta = gen$zeta[keep, , drop = FALSE],
             omega = gen$omega[keep], sigma_u = gen$sigma_u[keep], sigma_v = gen$sigma_v[keep],
             beta = gen$beta[keep, , drop = FALSE], names = gen$agents[keep])
  if (A == 10) {
    old <- if (exists(".Random.seed", envir = globalenv())) get(".Random.seed", envir = globalenv())
    set.seed(synth_seed)
    jit <- function(M) M + matrix(rnorm(length(M), 0, synth_sd), nrow(M))
    ag$gamma <- rbind(ag$gamma, jit(gen$gamma)); ag$eta <- rbind(ag$eta, jit(gen$eta))
    ag$alpha <- rbind(ag$alpha, jit(gen$alpha)); ag$zeta <- rbind(ag$zeta, jit(gen$zeta))
    ag$omega <- c(ag$omega, plogis(qlogis(gen$omega) + rnorm(5, 0, synth_sd)))
    ag$sigma_u <- c(ag$sigma_u, exp(log(gen$sigma_u) + rnorm(5, 0, synth_sd)))
    ag$sigma_v <- c(ag$sigma_v, exp(log(gen$sigma_v) + rnorm(5, 0, synth_sd)))
    ag$beta <- rbind(ag$beta, jit(gen$beta))
    ag$names <- c(ag$names, paste0(gen$agents, "-synthetic"))
    if (!is.null(old)) assign(".Random.seed", old, envir = globalenv())
  }
  ag
}

# ---- conflict calibration ----------------------------------------------------
# Expected share of all spawned targets that are contested, averaging over the person
# distribution of kappa and the round effects u_r, weighting AI types equally and
# densities by their mean number of spawned targets.
expected_conflict <- function(par, shift = 0, n_mc = 20000) {
  z <- qnorm((seq_len(n_mc) - 0.5) / n_mc)                  # deterministic N(0,1) grid
  zk <- z[((seq_len(n_mc) * 7919) %% n_mc) + 1]             # fixed permutation: decorrelates
                                                            # kappa and u without using the RNG
  w_c <- sapply(par$N_spawned, mean); w_c <- w_c / sum(w_c)
  A <- nrow(par$gamma); tot <- 0
  for (a in 1:A) for (c in 1:DENS_N) {
    x <- par$sigma_kappa * zk + par$gamma[a, c] + shift + par$sigma_u[a] * z
    tot <- tot + w_c[c] * mean(1 - plogis(x)) / A
  }
  tot
}
conflict_shift <- function(par, target) {
  if (is.na(target)) return(0)
  uniroot(function(s) expected_conflict(par, s) - target, c(-15, 15), tol = 1e-6)$root
}

# ---- full parameter set for one condition ----------------------------------------
condition_parameters <- function(gen, cond) {
  ag <- make_agents(gen, cond$A)
  par <- c(gen[c("sigma_theta", "sigma_kappa", "r", "lambda", "b0", "N_spawned")], ag)
  # Identical efficacy predictions after changing A, while satisfying sum(alpha)=0.
  before <- (1-par$omega)*par$alpha-par$b0
  delta <- sum(par$alpha)/sum(matrix(1/(1-par$omega),nrow=nrow(par$alpha),ncol=DENS_N))
  par$alpha <- par$alpha-delta/(1-par$omega)
  par$b0 <- par$b0-delta
  stopifnot(abs(sum(par$alpha))<1e-9,
    max(abs(before-((1-par$omega)*par$alpha-par$b0)))<1e-9)
  par$alpha_reanchoring_shift <- delta
  par$shift <- conflict_shift(par, cond$conflict)
  par$gamma <- par$gamma + par$shift
  par$expected_conflict <- expected_conflict(par, 0)
  par
}

# ---- one simulated data set ------------------------------------------------------
# Each person plays 2 AI types (balanced over all pairs; both when A = 2), each at both
# densities, K rounds per AI x density -> 4K rounds per person.
simulate_dataset <- function(par, H, K, seed) {
  set.seed(seed)
  A <- nrow(par$gamma)
  pairs <- if (A == 2) matrix(1:2, 1) else t(combn(A, 2))
  pairs <- pairs[sample(nrow(pairs)), , drop = FALSE]       # random pair order per data set
  S <- matrix(c(par$sigma_theta^2, par$r * par$sigma_theta * par$sigma_kappa,
                par$r * par$sigma_theta * par$sigma_kappa, par$sigma_kappa^2), 2)
  P <- matrix(rnorm(2 * H), H) %*% chol(S)
  theta <- P[, 1]; kappa <- P[, 2]

  des <- expand.grid(k = 1:K, c = 1:DENS_N, slot = 1:2, h = 1:H)
  des$a <- pairs[cbind(((des$h - 1) %% nrow(pairs)) + 1, des$slot)]
  R <- nrow(des)
  N <- integer(R)
  for (c in 1:DENS_N) {
    idx <- which(des$c == c)
    N[idx] <- sample(par$N_spawned[[c]], length(idx), replace = TRUE)
  }
  ac <- cbind(des$a, des$c)
  u <- rnorm(R, 0, par$sigma_u[des$a]); v <- rnorm(R, 0, par$sigma_v[des$a])
  pi_ <- plogis(kappa[des$h] + par$gamma[ac] + u)
  q   <- plogis(theta[des$h] - par$eta[ac])
  s   <- plogis(par$omega[des$a] * theta[des$h] + (1 - par$omega[des$a]) * par$alpha[ac] - par$b0 + v)
  rho <- plogis(par$lambda * theta[des$h] - par$zeta[ac])
  s1 <- plogis(qlogis(s)+par$beta[ac])
  p <- cbind(pi_*(1-s),pi_*s*rho,pi_*s*(1-rho),
             (1-pi_)*(1-s1),(1-pi_)*s1*q,(1-pi_)*s1*(1-q))
  stopifnot(all(is.finite(p)),all(p>=0),max(abs(rowSums(p)-1))<1e-10)
  n <- t(vapply(seq_len(R), function(r) as.vector(rmultinom(1, N[r], p[r, ])), integer(6)))

  list(data = list(R = R, H = H, A = A, C = DENS_N, hh = des$h, aa = des$a, cc = des$c, n = n,
                   T = 2L*H, tt = as.integer((des$h-1L)*2L+des$slot),
                   alpha_basis = unname(qr.Q(qr(contr.helmert(A*DENS_N))))),
       truth = list(theta = theta, kappa = kappa),
       realized_conflict = sum(n[, 4:6]) / sum(n))
}

# named vector of true values, matching Stan's variable names
truth_vector <- function(par, truth) {
  A <- nrow(par$gamma); C <- DENS_N
  m <- function(name, M) setNames(as.vector(M),
                                  sprintf("%s[%d,%d]", name, rep(1:A, C), rep(1:C, each = A)))
  v <- function(name, x) setNames(x, sprintf("%s[%d]", name, seq_along(x)))
  c(v("theta", truth$theta), v("kappa", truth$kappa),
    m("gamma", par$gamma), m("eta", par$eta), m("alpha", par$alpha), m("zeta", par$zeta), m("beta", par$beta),
    m("ai_contrib", (1 - par$omega) * par$alpha),
    v("omega", par$omega), v("sigma_u", par$sigma_u), v("sigma_v", par$sigma_v),
    c(b0 = par$b0, lambda_std = par$lambda*par$sigma_theta, lambda = par$lambda, sigma_theta = par$sigma_theta, sigma_kappa = par$sigma_kappa,
      r_theta_kappa = par$r))
}

