source('sim/sim_config.R');source('sim/sim_functions.R')
emp<-Sys.getenv('HAI_EMPIRICAL_ROOT','../full_model')
stopifnot(identical(unname(tools::md5sum('stan/M1_empirical_reference.stan')),
 unname(tools::md5sum(file.path(emp,'stan/M1_hai_trtree.stan')))))
x<-readRDS(file.path(emp,'data/prepared_data.rds'))
stopifnot(x$stan$R==1108L,sum(x$stan$n)==180668L)
if(!file.exists(file.path(emp,'output/M1/fit.rds')))stop('Run the NEW 1108-round full_model M1 fit first.')
fit<-readRDS(file.path(emp,'output/M1/fit.rds'))
gen<-extract_generating_values(fit,x$rounds)
stopifnot(length(gen$N_spawned)==2L,abs(sum(gen$alpha))<1e-7,
 all(is.finite(unlist(gen[setdiff(names(gen),'agents')]))))
gen$provenance<-list(empirical_root=emp,fit_md5=unname(tools::md5sum(file.path(emp,'output/M1/fit.rds'))),
 data_md5=unname(tools::md5sum(file.path(emp,'data/prepared_data.rds'))),
 stan_md5=unname(tools::md5sum('stan/M1_empirical_reference.stan')),
 n_rounds=x$stan$R,n_targets=sum(x$stan$n),timestamp=as.character(Sys.time()))
if(file.exists(GEN_FILE)){
 old<-readRDS(GEN_FILE)
 stopifnot(identical(old$provenance$fit_md5,gen$provenance$fit_md5),
   identical(old$provenance$data_md5,gen$provenance$data_md5),
   identical(old$provenance$stan_md5,gen$provenance$stan_md5))
 gen<-old # Preserve the checkpoint fingerprint on a resumed run.
}else saveRDS(gen,GEN_FILE)
des<-DESIGN
pars<-lapply(seq_len(nrow(des)),function(i)condition_parameters(gen,des[i,]))
des$conflict_shift<-vapply(pars,`[[`,0,'shift')
des$expected_conflict<-vapply(pars,`[[`,0,'expected_conflict')
des$rounds_per_person<-4*des$K;des$total_rounds<-des$H*des$rounds_per_person
write.csv(des,'sim/design_grid.csv',row.names=FALSE)
saveRDS(pars,'sim/condition_parameters.rds')
cat('Generating values: server full-data M1 posterior means, all four chains.\n')
print(des,row.names=FALSE);cat('Baseline model-implied target-weighted conflict:',
 expected_conflict(condition_parameters(gen,des[des$H==277&des$K==1&des$A==5&is.na(des$conflict),])),'\n')
