args<-commandArgs(trailingOnly=TRUE)
for(s in c('sim/01_generating_values.R','sim/preflight.R','sim/02_run_simulation.R')){
 cat('\nSTEP',s,'\n');flush.console()
 status<-system2(file.path(R.home('bin'),'Rscript'),c('--vanilla',s,if(s=='sim/02_run_simulation.R')args))
 if(status!=0L)stop('Simulation step failed: ',s)
}
